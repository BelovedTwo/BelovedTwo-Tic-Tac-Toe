﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace TicTacToe
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region Private Members
        /// <summary>
        /// Holds the current results of cells in the active game
        /// </summary>
        private MarkType[] mResult;
        /// <summary>
        /// True if it is player 1's turn (X) or player 2's turn (O)
        /// </summary>
        private bool mPlayer1Turn;
        /// <summary>
        /// True if the game has ended
        /// </summary>
        private bool mGameEnded;
        #endregion

        #region Constructor
        /// <summary>
        /// Default Constructor
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();

            NewGame();
        }

        #endregion

        /// <summary>
        /// Starts a new game and clears all the values back to the start
        /// </summary>
        private void NewGame()
        {
            //ne blank array of free cells
            mResult = new MarkType[9];

            for (var i = 0; i < mResult.Length; i++)
            {
                mResult[i] = MarkType.Free;

                mPlayer1Turn = true;
                //Iterate every button on the grid
                Container.Children.Cast<Button>().ToList().ForEach(button =>
                {
                    //Change background,foreground and content to default values
                    button.Content = string.Empty;
                    button.Background = Brushes.White;
                    button.Foreground = Brushes.Blue;
                });

                //Make sure the game hasn't finished
                mGameEnded=false;
                

            };
        }

        /// <summary>
        /// Handles a button click event
        /// </summary>
        /// <param name="sender">The button that was clicked</param>
        /// <param name="e">The events of the click</param>
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // Start a new game on the click after it finished
            if (mGameEnded)
            {
                NewGame();
                return;
            }

            //cast the sender to a button 
            var button = (Button)sender;
            //Find the buttons position in the array
            var column = Grid.GetColumn(button);
            var row = Grid.GetRow(button);

            var index = column + (row * 3);

            //Don't do anything if the cell already has a value in it
            if (mResult[index] != MarkType.Free)
            {
                return;
            }

            //Set the value based on which player s turn it is
            //using turnary instaed of normal if and else hence the other one is commented out

            mResult[index] = mPlayer1Turn ? MarkType.Cross : MarkType.Nought;
            /*if (mPlayer1Turn)
            {
                mResult[index] = MarkType.Cross;
            }
            else
            {
                mResult[index] = MarkType.Nought;
            }*/

            //Set button text to the results
            button.Content = mPlayer1Turn ? "X" : "O";

            if (!mPlayer1Turn)
            {
                button.Foreground = Brushes.DarkRed;
            }
            //Toggles the players turn
            //mPlayer1Turn^=false; Can be written this way
            if (mPlayer1Turn)
            {
                mPlayer1Turn = false;
            }
            else
            {
                mPlayer1Turn=true;
            }

            //Check for a winner
            CheckForWinner();
        }

        /// <summary>
        /// Checks if there's a winner of three line straight
        /// </summary>
        /// <exception cref="NotImplementedException"></exception>
        private void CheckForWinner()
        {
            #region Horizontal Wins
            //Check for horizontal wins
            //
            // -row0
            if (mResult[0]!=MarkType.Free && (mResult[0] & mResult[1] & mResult[2]) == mResult[0])
            {
    
                //Highlight the winning cells in green
                Button0_0.Background = Button1_0.Background = Button2_0.Background = Brushes.Green;

                //The game ends
                mGameEnded = true;
            }
            //
            // -row0
            if (mResult[3] != MarkType.Free && (mResult[3] & mResult[4] & mResult[5]) == mResult[3])
            {
                //Highlight the winning cells in green
                Button0_1.Background = Button1_1.Background = Button2_1.Background = Brushes.Green;
                //The game ends
                mGameEnded = true;
            }
            //
            // -row0
            if (mResult[6] != MarkType.Free && (mResult[6] & mResult[7] & mResult[8]) == mResult[6])
            {
                //Highlight the winning cells in green
                Button0_2.Background = Button1_2.Background = Button2_2.Background = Brushes.Green;

                //The game ends
                mGameEnded = true;
            }
            #endregion

            #region Vertical Wins
            //Check for vertical wins
            //
            // -Column 0
            if (mResult[0] != MarkType.Free && (mResult[0] & mResult[3] & mResult[6]) == mResult[0])
            {
                //Highlight the winning cells in green
                Button0_0.Background = Button0_1.Background = Button0_2.Background = Brushes.Green;

                //The game ends
                mGameEnded = true;
            }
            //
            // -Column 1
            if (mResult[1] != MarkType.Free && (mResult[1] & mResult[4] & mResult[7]) == mResult[1])
            {
                //Highlight the winning cells in green
                Button1_0.Background = Button1_1.Background = Button1_2.Background = Brushes.Green;

                //The game ends
                mGameEnded = true;
            }
            //
            // -Column 2
            if (mResult[2] != MarkType.Free && (mResult[2] & mResult[5] & mResult[8]) == mResult[2])
            {
                //Highlight the winning cells in green
                Button2_0.Background = Button2_1.Background = Button2_2.Background = Brushes.Green;

                //The game ends
                mGameEnded = true;
            }
            #endregion

            #region Diagnal Wins 
            //Check for diagnal wins
            //
            // -Top Left Bottom Right
            if (mResult[0] != MarkType.Free && (mResult[0] & mResult[4] & mResult[8]) == mResult[0])
            {
                //Highlight the winning cells in green
                Button0_0.Background = Button1_1.Background = Button2_2.Background = Brushes.Green;

                //The game ends
                mGameEnded = true;
            }
            //
            // -Top Right Bottom Left
            if (mResult[2] != MarkType.Free && (mResult[2] & mResult[4] & mResult[6]) == mResult[2])
            {
                //Highlight the winning cells in green
                Button2_0.Background = Button1_1.Background = Button0_2.Background = Brushes.Green;

                //The game ends
                mGameEnded = true;
            }

            #endregion

            #region No winners
            //Chcek for no winner and full board
            if (!mResult.Any(f=> f==MarkType.Free))
            {

                //Turn all cells to orange
                Container.Children.Cast<Button>().ToList().ForEach(button =>
                {
                    //Change background
                    button.Background = Brushes.Orange;
                });

                //Game ended
                mGameEnded = true;
            }
            #endregion

            


        }
    }
}
